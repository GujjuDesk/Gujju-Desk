<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>
<?php 
    return [
        "idname" => "auto-follow",
        "plugin_name" => "Auto Follow",
        "plugin_uri" => "http://getnextpost.io",
        "author" => "Nextpost",
        "author_uri" => "http://getnextpost.io",
        "version" => "1.0.0",
        "desc" => "Most smarter & fast module for whom wants to increase page followers.",
        "icon_style" => "background-color: #EB4B92; background: linear-gradient(134.72deg, #EB4B92 0%, #CA76E3 100%); color: #fff;"
    ];
    