<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>
<?php 
    return [
        "idname" => "welcomedm",
        "plugin_name" => "Auto DM (New Followers)",
        "plugin_uri" => "http://getnextpost.io",
        "author" => "Nextpost",
        "author_uri" => "http://getnextpost.io",
        "version" => "1.0.0",
        "desc" => "Module to send automated direct message to your new followers",
        "icon_style" => "background-color: #3BE8B0; background: linear-gradient(-135deg, #3BE8B0 0%, #02CDFF 100%); color: #fff; font-size: 18px;"
    ];
    