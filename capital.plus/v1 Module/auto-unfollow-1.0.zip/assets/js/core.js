/**
 * AutoUnfollow Namespace
 */
var AutoUnfollow = {};



/**
 * AutoUnfollow Schedule Form
 */
AutoUnfollow.ScheduleForm = function()
{
}


/**
 * Auto Follow Index
 */
AutoUnfollow.Index = function()
{
    $(document).ajaxComplete(function(event, xhr, settings) {
        var rx = new RegExp("(auto-unfollow\/[0-9]+(\/)?)$");
        if (rx.test(settings.url)) {
            AutoUnfollow.ScheduleForm();
        }
    })
}