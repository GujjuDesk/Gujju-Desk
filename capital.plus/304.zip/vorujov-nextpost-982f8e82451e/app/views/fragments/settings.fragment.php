        <div class="skeleton skeleton--full" id="settings">
            <div class="clearfix">
                <aside class="skeleton-aside">
                    <?php require_once(APPPATH.'/views/fragments/settings/menu.fragment.php'); ?>
                </aside>

                <section class="skeleton-content">
                    <?php require_once(APPPATH.'/views/fragments/settings/'.$page.'.fragment.php'); ?>
                </section>
            </div>
        </div>