        <div id="welcome" class="step">
            <h1 class="title">Nextpost Installation</h1>
            <p>
                Welcome! Nextpost is an Instagram auto posting web application that allows you to 
                auto post, schedule and manage your Instagram accounts at the same time. 
            </p>
            <p class="fw-600 mb-40">
                Installation process is very easy and it only takes 59 seconds!
            </p>

            <a href="javascript:void(0)" class="oval button next-btn" data-next="#requirements">Start Installation</a>
        </div>