<?php 
    header("Location: ../");
    exit;